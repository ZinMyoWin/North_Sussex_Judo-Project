package NorthSussexJudo;

public class NorthSussexJudo {

	public static void main(String[] args) {
		InputCollector inputcollector = new InputCollector();
		inputcollector.collectInput();
		
		
	}

}
